import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'screens/memory_screen.dart';
import 'services/database_service.dart';

const MethodChannel memvexaWidgetChannel = MethodChannel('de.recalldevelopment.memvexa.app/widget');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseService.instance.database;
  runApp(const MemvexaApp());
}

class MemvexaApp extends StatefulWidget {
  const MemvexaApp({super.key});

  @override
  State<MemvexaApp> createState() => _MemvexaAppState();
}

class _MemvexaAppState extends State<MemvexaApp> {
  final navigatorKey = GlobalKey<NavigatorState>();

  @override
  void initState() {
    super.initState();
    memvexaWidgetChannel.setMethodCallHandler((call) async {
      if (call.method == 'widgetAction') {
        _handleWidgetAction(call.arguments as String?);
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        final action = await memvexaWidgetChannel.invokeMethod<String>('getInitialAction');
        _handleWidgetAction(action);
      } catch (_) {}
    });
  }

  void _handleWidgetAction(String? action) {
    final nav = navigatorKey.currentState;
    if (nav == null || action == null || action.isEmpty) return;
    if (action == 'search') {
      nav.push(MaterialPageRoute(builder: (_) => const MemoryScreen()));
    } else if (action == 'quick_add') {
      nav.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen(autoFocus: true)),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'MEMVEXA',
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2F6BFF)),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2F6BFF),
          brightness: Brightness.dark,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
