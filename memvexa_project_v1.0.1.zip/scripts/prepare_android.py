from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
android = root / 'android'
app = android / 'app'
pkg = 'de.recalldevelopment.memvexa.app'
pkg_path = app / 'src/main/kotlin/de/recalldevelopment/memvexa'
pkg_path.mkdir(parents=True, exist_ok=True)

# Remove any generated MainActivity in a different package.
for f in (app / 'src/main/kotlin').rglob('MainActivity.kt'):
    if f.parent != pkg_path:
        f.unlink()

main_activity = r'''package de.recalldevelopment.memvexa.app

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "de.recalldevelopment.memvexa.app/widget"
    private var channel: MethodChannel? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        channel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
        channel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "getInitialAction" -> {
                    result.success(intent?.getStringExtra("widget_action"))
                    intent?.removeExtra("widget_action")
                }
                "updateWidget" -> {
                    val count = call.argument<Int>("count") ?: 0
                    val latest = call.argument<String>("latest") ?: ""
                    getSharedPreferences("memvexa_widget", MODE_PRIVATE)
                        .edit().putInt("count", count).putString("latest", latest).apply()
                    val manager = AppWidgetManager.getInstance(this)
                    val ids = manager.getAppWidgetIds(ComponentName(this, MemvexaWidgetProvider::class.java))
                    ids.forEach { MemvexaWidgetProvider.updateWidget(this, manager, it) }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra("widget_action")?.let {
            channel?.invokeMethod("widgetAction", it)
            intent.removeExtra("widget_action")
        }
    }
}
'''
(pkg_path / 'MainActivity.kt').write_text(main_activity, encoding='utf-8')

provider = r'''package de.recalldevelopment.memvexa.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class MemvexaWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateWidget(context, appWidgetManager, it) }
    }

    companion object {
        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val prefs = context.getSharedPreferences("memvexa_widget", Context.MODE_PRIVATE)
            val count = prefs.getInt("count", 0)
            val latest = prefs.getString("latest", "") ?: ""
            val views = RemoteViews(context.packageName, R.layout.memvexa_widget)
            views.setTextViewText(R.id.widget_count, "$count gespeichert")
            views.setTextViewText(R.id.widget_latest, if (latest.isBlank()) "Bereit für deine erste Erinnerung" else "Zuletzt: $latest")

            fun actionIntent(action: String, requestCode: Int): PendingIntent {
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("widget_action", action)
                }
                return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            }

            views.setOnClickPendingIntent(R.id.widget_quick_add, actionIntent("quick_add", 1001))
            views.setOnClickPendingIntent(R.id.widget_search, actionIntent("search", 1002))
            views.setOnClickPendingIntent(R.id.widget_root, actionIntent("open", 1003))
            manager.updateAppWidget(widgetId, views)
        }
    }
}
'''
(pkg_path / 'MemvexaWidgetProvider.kt').write_text(provider, encoding='utf-8')

# Resources.
layout = app / 'src/main/res/layout'
xml = app / 'src/main/res/xml'
drawable = app / 'src/main/res/drawable'
values = app / 'src/main/res/values'
for d in (layout, xml, drawable, values): d.mkdir(parents=True, exist_ok=True)

(layout / 'memvexa_widget.xml').write_text(r'''<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center_vertical"
    android:padding="16dp"
    android:background="@drawable/memvexa_widget_background">

    <TextView android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:text="MEMVEXA" android:textStyle="bold" android:textSize="18sp" android:textColor="#FFFFFF" />
    <TextView android:id="@+id/widget_count" android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:layout_marginTop="4dp" android:text="0 gespeichert" android:textSize="13sp" android:textColor="#CFE0FF" />
    <TextView android:id="@+id/widget_latest" android:layout_width="match_parent" android:layout_height="wrap_content"
        android:layout_marginTop="4dp" android:maxLines="1" android:ellipsize="end" android:textSize="12sp" android:textColor="#AFC4EE" />
    <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" android:layout_marginTop="12dp">
        <Button android:id="@+id/widget_quick_add" android:layout_width="0dp" android:layout_height="44dp" android:layout_weight="1"
            android:text="+ Merken" android:textAllCaps="false" />
        <Space android:layout_width="8dp" android:layout_height="1dp" />
        <Button android:id="@+id/widget_search" android:layout_width="0dp" android:layout_height="44dp" android:layout_weight="1"
            android:text="Suchen" android:textAllCaps="false" />
    </LinearLayout>
</LinearLayout>
''', encoding='utf-8')

(drawable / 'memvexa_widget_background.xml').write_text(r'''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient android:angle="315" android:startColor="#07142F" android:centerColor="#0E1C42" android:endColor="#080D1D" />
    <corners android:radius="24dp" />
    <stroke android:width="1dp" android:color="#334A86" />
</shape>
''', encoding='utf-8')

(xml / 'memvexa_widget_info.xml').write_text(r'''<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="250dp"
    android:minHeight="110dp"
    android:minResizeWidth="180dp"
    android:minResizeHeight="90dp"
    android:updatePeriodMillis="0"
    android:initialLayout="@layout/memvexa_widget"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen"
    android:description="@string/widget_description" />
''', encoding='utf-8')

strings_path = values / 'strings.xml'
strings_path.write_text('''<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">MEMVEXA</string>\n    <string name="widget_description">MEMVEXA Schnellzugriff für Erinnerungen</string>\n</resources>\n''', encoding='utf-8')

# Manifest with launcher and widget receiver.
manifest = app / 'src/main/AndroidManifest.xml'
manifest.write_text(r'''<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:label="MEMVEXA"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:taskAffinity=""
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data android:name="io.flutter.embedding.android.NormalTheme" android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <receiver android:name=".MemvexaWidgetProvider" android:exported="false">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/memvexa_widget_info" />
        </receiver>
        <meta-data android:name="flutterEmbedding" android:value="2" />
    </application>
    <queries>
        <intent>
            <action android:name="android.intent.action.PROCESS_TEXT" />
            <data android:mimeType="text/plain" />
        </intent>
    </queries>
</manifest>
''', encoding='utf-8')

# Stable application ID and stable release signing.
gradle = app / 'build.gradle.kts'
gradle.write_text(r'''import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("kotlin-android")
    id("dev.flutter.flutter-gradle-plugin")
}

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "de.recalldevelopment.memvexa.app"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = JavaVersion.VERSION_17.toString() }

    defaultConfig {
        applicationId = "de.recalldevelopment.memvexa.app"
        minSdk = 24
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = keystoreProperties["storeFile"]?.let { file(it) }
            storePassword = keystoreProperties["storePassword"] as String
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

flutter { source = "../.." }
''', encoding='utf-8')

print('MEMVEXA Android configuration prepared.')
