MEMVEXA CLEAN BUILD PACKAGE

Package ID: de.recalldevelopment.memvexa
App name: MEMVEXA
Version: 1.0.0 (build 1)
Minimum Android: API 24 / Android 7

Included:
- Rebranded Flutter source
- Local SQLite storage
- MEMVEXA launcher icon
- Native Android home-screen widget
  * + Merken opens quick entry
  * Suchen opens memories
  * shows saved count and latest memory
- Android preparation script
- Stable release-signing workflow template

GitHub repository needs these two files at root / workflow path:
1) memvexa_project.zip at repository root
2) .github/workflows/build-android.yml

Required GitHub Action secrets:
- MEMVEXA_KEYSTORE_PASSWORD
- MEMVEXA_KEYSTORE_BASE64

The keystore itself must NEVER be committed to a public repository.
