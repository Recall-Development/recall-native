class Memory {
  final String id, title, content, category;
  final String? notes;
  final DateTime createdAt, updatedAt;
  const Memory({required this.id, required this.title, required this.content, required this.category, this.notes, required this.createdAt, required this.updatedAt});
  Map<String,Object?> toMap()=>{'id':id,'title':title,'content':content,'category':category,'notes':notes,'created_at':createdAt.toIso8601String(),'updated_at':updatedAt.toIso8601String()};
  factory Memory.fromMap(Map<String,Object?> m)=>Memory(
    id:m['id'] as String,title:m['title'] as String,content:m['content'] as String,category:m['category'] as String,notes:m['notes'] as String?,
    createdAt:DateTime.parse(m['created_at'] as String),updatedAt:DateTime.parse(m['updated_at'] as String));
}
