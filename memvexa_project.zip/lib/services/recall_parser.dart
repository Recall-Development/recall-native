class ParsedRecallInput {
  final String raw;
  final String? item, location, container, position;
  const ParsedRecallInput({required this.raw,this.item,this.location,this.container,this.position});
}

class RecallParser {
  static const rooms=['wohnzimmer','küche','keller','garage','schlafzimmer','bad','flur','dachboden','büro','abstellraum'];
  static const containers=['schublade','schrank','kiste','regal','tasche','geldbeutel','werkzeugkasten','box'];
  static ParsedRecallInput parse(String input){
    final t=input.trim(), l=t.toLowerCase();
    String? find(List<String> vals){for(final v in vals){if(l.contains(v))return v;}return null;}
    String? item;
    for(final p in [
      RegExp(r'(?:mein|meine|meinen)\s+(.+?)\s+(?:liegt|liegen|ist|sind)\s',caseSensitive:false),
      RegExp(r'(.+?)\s+(?:liegt|liegen)\s+(?:im|in der|in dem|bei)',caseSensitive:false)
    ]){
      final m=p.firstMatch(t); if(m!=null){item=m.group(1)?.trim();break;}
    }
    final pos=find(['oben rechts','oben links','unten rechts','unten links','oben','unten','rechts','links','hinten','vorne']);
    return ParsedRecallInput(raw:t,item:item,location:find(rooms),container:find(containers),position:pos);
  }
}
