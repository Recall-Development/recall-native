import 'package:flutter/material.dart';
import '../models/memory.dart';
import '../services/database_service.dart';

class MemoryScreen extends StatefulWidget {
  const MemoryScreen({super.key});
  @override
  State<MemoryScreen> createState() => _MemoryScreenState();
}

class _MemoryScreenState extends State<MemoryScreen> {
  final q = TextEditingController();
  List<Memory> data = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final d = await DatabaseService.instance.listMemories(query: q.text);
    if (mounted) setState(() { data = d; loading = false; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Erinnerungen')),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  controller: q,
                  onChanged: (_) => load(),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Erinnerungen durchsuchen …',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Expanded(
                child: loading
                    ? const Center(child: CircularProgressIndicator())
                    : data.isEmpty
                        ? const Center(child: Text('Noch nichts gespeichert.'))
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                            itemCount: data.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (context, i) {
                              final m = data[i];
                              return Card(
                                child: ListTile(
                                  title: Text(m.title),
                                  subtitle: Text([m.content, if ((m.notes ?? '').isNotEmpty) m.notes!].join('\n')),
                                  isThreeLine: true,
                                  trailing: IconButton(
                                    icon: const Icon(Icons.delete_outline),
                                    onPressed: () async {
                                      await DatabaseService.instance.deleteMemory(m.id);
                                      load();
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            ],
          ),
        ),
      );
}
