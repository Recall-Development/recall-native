import 'package:flutter/material.dart';
import '../models/memory.dart';
import '../services/database_service.dart';
import 'home_screen.dart';
import 'watch_screen.dart';
import 'memvexa_screen.dart';

class MemoryScreen extends StatefulWidget {
  final String title;
  final String? initialQuery;
  const MemoryScreen({super.key, this.title = 'Erinnerungen', this.initialQuery});

  @override
  State<MemoryScreen> createState() => _MemoryScreenState();
}

class _MemoryScreenState extends State<MemoryScreen> {
  late final TextEditingController q;
  List<Memory> data = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    q = TextEditingController(text: widget.initialQuery ?? '');
    load();
  }

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final d = await DatabaseService.instance.listMemories(query: q.text);
    if (mounted) setState(() { data = d; loading = false; });
  }

  void _nav(int index) {
    if (index == 3) return;
    Widget screen;
    switch (index) {
      case 0:
        screen = const HomeScreen();
        break;
      case 1:
        screen = const WatchScreen();
        break;
      case 2:
        screen = const HomeScreen(autoFocus: true);
        break;
      case 4:
        screen = const MemvexaScreen();
        break;
      default:
        return;
    }
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => screen), (_) => false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(
                  controller: q,
                  onChanged: (_) => load(),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'Erinnerungen durchsuchen …',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Expanded(
                child: loading
                    ? const Center(child: CircularProgressIndicator())
                    : data.isEmpty
                        ? const Center(child: Text('Noch nichts gespeichert.'))
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                            itemCount: data.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (context, i) {
                              final m = data[i];
                              return Card(
                                child: ListTile(
                                  title: Text(m.title),
                                  subtitle: Text([m.content, if ((m.notes ?? '').isNotEmpty) m.notes!].join('\n')),
                                  isThreeLine: true,
                                  trailing: IconButton(
                                    icon: const Icon(Icons.delete_outline),
                                    onPressed: () async {
                                      await DatabaseService.instance.deleteMemory(m.id);
                                      load();
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: 3,
          onDestinationSelected: _nav,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.visibility_outlined), label: 'Watch'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), label: '+'),
            NavigationDestination(icon: Icon(Icons.memory), label: 'Memory'),
            NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'MEMVEXA'),
          ],
        ),
      );
}
