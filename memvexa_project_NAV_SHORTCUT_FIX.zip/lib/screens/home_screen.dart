import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uuid/uuid.dart';
import '../models/memory.dart';
import '../services/database_service.dart';
import '../services/recall_parser.dart';
import 'memory_screen.dart';
import 'watch_screen.dart';
import 'memvexa_screen.dart';

const MethodChannel _widgetChannel = MethodChannel('de.recalldevelopment.memvexa/widget');

class HomeScreen extends StatefulWidget {
  final bool autoFocus;
  const HomeScreen({super.key, this.autoFocus = false});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final c = TextEditingController();
  final focusNode = FocusNode();
  int memories = 0, items = 0, locations = 0;

  @override
  void initState() {
    super.initState();
    refresh();
    if (widget.autoFocus) {
      WidgetsBinding.instance.addPostFrameCallback((_) => focusNode.requestFocus());
    }
  }

  @override
  void dispose() {
    c.dispose();
    focusNode.dispose();
    super.dispose();
  }

  Future<void> refresh() async {
    final v = await Future.wait([
      DatabaseService.instance.count('memories'),
      DatabaseService.instance.count('items'),
      DatabaseService.instance.count('locations'),
    ]);
    final latest = await DatabaseService.instance.latestMemory();
    if (mounted) {
      setState(() {
        memories = v[0];
        items = v[1];
        locations = v[2];
      });
    }
    try {
      await _widgetChannel.invokeMethod('updateWidget', {
        'count': v[0],
        'latest': latest?.title ?? '',
      });
    } catch (_) {}
  }

  Future<void> _openMemory({String title = 'Erinnerungen', String? initialQuery}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MemoryScreen(title: title, initialQuery: initialQuery),
      ),
    );
    await refresh();
  }

  Future<void> analyze() async {
    final raw = c.text.trim();
    if (raw.isEmpty) return;
    final p = RecallParser.parse(raw);
    final ok = await showDialog<bool>(
      context: context,
      builder: (x) => AlertDialog(
        title: const Text('MEMVEXA hat Folgendes erkannt'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Gegenstand: ${p.item ?? "nicht eindeutig"}'),
            Text('Ort: ${p.location ?? "nicht erkannt"}'),
            Text('Behälter: ${p.container ?? "nicht erkannt"}'),
            Text('Position: ${p.position ?? "nicht erkannt"}'),
            const SizedBox(height: 12),
            const Text('Die Verarbeitung erfolgt vollständig lokal auf diesem Gerät.'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(x, false), child: const Text('Abbrechen')),
          FilledButton(onPressed: () => Navigator.pop(x, true), child: const Text('Speichern')),
        ],
      ),
    );
    if (ok != true) return;
    final now = DateTime.now();
    await DatabaseService.instance.saveMemory(
      Memory(
        id: const Uuid().v4(),
        title: (p.item?.isNotEmpty ?? false) ? p.item! : 'Erinnerung',
        content: raw,
        category: 'Gegenstand',
        notes: [p.location, p.container, p.position].whereType<String>().join(' · '),
        createdAt: now,
        updatedAt: now,
      ),
    );
    await DatabaseService.instance.saveParsedEntities(
      item: p.item,
      location: p.location,
      container: p.container,
      position: p.position,
      raw: raw,
    );
    c.clear();
    await refresh();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gespeichert – vollständig lokal.')),
      );
    }
  }

  void _onNavTap(int index) {
    switch (index) {
      case 0:
        break;
      case 1:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const WatchScreen()));
        break;
      case 2:
        focusNode.requestFocus();
        break;
      case 3:
        _openMemory();
        break;
      case 4:
        Navigator.push(context, MaterialPageRoute(builder: (_) => const MemvexaScreen()));
        break;
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('MEMVEXA'),
          actions: [
            IconButton(
              tooltip: 'Gespeicherte Erinnerungen',
              icon: const Icon(Icons.memory_outlined),
              onPressed: () => _openMemory(),
            )
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(
                'Dein Leben. Sofort gefunden.',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              const Text('Privat und lokal. Ohne Cloud-KI, ohne laufende API-Kosten.'),
              const SizedBox(height: 24),
              TextField(
                controller: c,
                focusNode: focusNode,
                minLines: 2,
                maxLines: 5,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Was soll MEMVEXA für dich merken?',
                  prefixIcon: Icon(Icons.auto_awesome),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: analyze,
                icon: const Icon(Icons.psychology_alt_outlined),
                label: const Text('MEMVEXA analysieren'),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: _Stat(
                      'Gespeichert',
                      memories,
                      onTap: () => _openMemory(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _Stat(
                      'Gegenstände',
                      items,
                      onTap: () => _openMemory(title: 'Gegenstände'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _Stat(
                      'Orte',
                      locations,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const MemvexaScreen(initialMode: MemvexaMode.locations)),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              OutlinedButton.icon(
                onPressed: () => _openMemory(),
                icon: const Icon(Icons.search),
                label: const Text('Erinnerungen durchsuchen'),
              ),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: 0,
          onDestinationSelected: _onNavTap,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.visibility_outlined), selectedIcon: Icon(Icons.visibility), label: 'Watch'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: '+'),
            NavigationDestination(icon: Icon(Icons.memory_outlined), selectedIcon: Icon(Icons.memory), label: 'Memory'),
            NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'MEMVEXA'),
          ],
        ),
      );
}

class _Stat extends StatelessWidget {
  final String label;
  final int value;
  final VoidCallback onTap;
  const _Stat(this.label, this.value, {required this.onTap});

  @override
  Widget build(BuildContext c) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
            child: Column(
              children: [
                Text('$value', style: Theme.of(c).textTheme.headlineSmall),
                const SizedBox(height: 4),
                FittedBox(child: Text(label)),
              ],
            ),
          ),
        ),
      );
}
