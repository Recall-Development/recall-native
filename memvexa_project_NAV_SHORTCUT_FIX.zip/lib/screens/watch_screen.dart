import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../services/database_service.dart';
import 'home_screen.dart';
import 'memory_screen.dart';
import 'memvexa_screen.dart';

class WatchScreen extends StatefulWidget {
  const WatchScreen({super.key});

  @override
  State<WatchScreen> createState() => _WatchScreenState();
}

class _WatchScreenState extends State<WatchScreen> {
  List<Map<String, Object?>> data = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final rows = await DatabaseService.instance.listWatchItems();
    if (mounted) setState(() { data = rows; loading = false; });
  }

  Future<void> addWatch() async {
    final controller = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Watch hinzufügen'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'z. B. Garantie Laptop endet im Oktober',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Abbrechen')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Speichern'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (title == null || title.isEmpty) return;
    await DatabaseService.instance.saveWatchItem(id: const Uuid().v4(), title: title);
    await load();
  }

  void _nav(int index) {
    if (index == 1) return;
    Widget screen;
    switch (index) {
      case 0:
        screen = const HomeScreen();
        break;
      case 2:
        screen = const HomeScreen(autoFocus: true);
        break;
      case 3:
        screen = const MemoryScreen();
        break;
      case 4:
        screen = const MemvexaScreen();
        break;
      default:
        return;
    }
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => screen), (_) => false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Watch')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: addWatch,
          icon: const Icon(Icons.add),
          label: const Text('Watch'),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : data.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Noch keine Watch-Einträge.\nMit „+ Watch“ kannst du Fristen, Garantien und Dinge zum Beobachten speichern.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: data.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) {
                      final row = data[i];
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.visibility_outlined),
                          title: Text(row['title'] as String? ?? ''),
                          subtitle: Text(row['status'] as String? ?? 'aktiv'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              await DatabaseService.instance.deleteWatchItem(row['id'] as String);
                              load();
                            },
                          ),
                        ),
                      );
                    },
                  ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: 1,
          onDestinationSelected: _nav,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.visibility), label: 'Watch'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), label: '+'),
            NavigationDestination(icon: Icon(Icons.memory_outlined), label: 'Memory'),
            NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'MEMVEXA'),
          ],
        ),
      );
}
