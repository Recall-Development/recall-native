import 'package:flutter/material.dart';
import '../models/memory.dart';
import '../services/database_service.dart';
import 'home_screen.dart';
import 'memory_screen.dart';
import 'watch_screen.dart';

enum MemvexaMode { search, locations }

class MemvexaScreen extends StatefulWidget {
  final MemvexaMode initialMode;
  const MemvexaScreen({super.key, this.initialMode = MemvexaMode.search});

  @override
  State<MemvexaScreen> createState() => _MemvexaScreenState();
}

class _MemvexaScreenState extends State<MemvexaScreen> {
  final q = TextEditingController();
  List<Memory> results = [];
  List<Map<String, Object?>> locations = [];
  bool searched = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialMode == MemvexaMode.locations) _loadLocations();
  }

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  Future<void> _loadLocations() async {
    final rows = await DatabaseService.instance.listLocations();
    if (mounted) setState(() => locations = rows);
  }

  Future<void> search() async {
    final query = q.text.trim().toLowerCase();
    if (query.isEmpty) return;
    final all = await DatabaseService.instance.listMemories();
    final words = query
        .replaceAll(RegExp(r'[^a-z0-9äöüß ]', caseSensitive: false), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.length > 2 && !{'wo', 'ist', 'sind', 'mein', 'meine', 'der', 'die', 'das', 'liegt', 'finde', 'ich'}.contains(w))
        .toList();

    int score(Memory m) {
      final hay = '${m.title} ${m.content} ${m.notes ?? ''}'.toLowerCase();
      return words.where(hay.contains).length;
    }

    final ranked = all.where((m) => score(m) > 0).toList()
      ..sort((a, b) => score(b).compareTo(score(a)));
    if (mounted) setState(() { results = ranked.take(10).toList(); searched = true; });
  }

  void _nav(int index) {
    if (index == 4) return;
    Widget screen;
    switch (index) {
      case 0:
        screen = const HomeScreen();
        break;
      case 1:
        screen = const WatchScreen();
        break;
      case 2:
        screen = const HomeScreen(autoFocus: true);
        break;
      case 3:
        screen = const MemoryScreen();
        break;
      default:
        return;
    }
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => screen), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final locationMode = widget.initialMode == MemvexaMode.locations;
    return Scaffold(
      appBar: AppBar(title: Text(locationMode ? 'Orte' : 'MEMVEXA fragen')),
      body: locationMode
          ? locations.isEmpty
              ? const Center(child: Text('Noch keine Orte gespeichert.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: locations.length,
                  itemBuilder: (context, i) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.place_outlined),
                      title: Text(locations[i]['name'] as String? ?? ''),
                    ),
                  ),
                )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text(
                  'Was möchtest du wiederfinden?',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: q,
                  autofocus: true,
                  onSubmitted: (_) => search(),
                  decoration: const InputDecoration(
                    hintText: 'z. B. Wo ist mein Ersatzschlüssel?',
                    prefixIcon: Icon(Icons.auto_awesome),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: search,
                  icon: const Icon(Icons.search),
                  label: const Text('MEMVEXA suchen lassen'),
                ),
                const SizedBox(height: 20),
                if (searched && results.isEmpty)
                  const Text('Dazu habe ich lokal noch keine passende Erinnerung gefunden.'),
                ...results.map((m) => Card(
                      child: ListTile(
                        leading: const Icon(Icons.memory_outlined),
                        title: Text(m.title),
                        subtitle: Text([m.content, if ((m.notes ?? '').isNotEmpty) m.notes!].join('\n')),
                      ),
                    )),
              ],
            ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 4,
        onDestinationSelected: _nav,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.visibility_outlined), label: 'Watch'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), label: '+'),
          NavigationDestination(icon: Icon(Icons.memory_outlined), label: 'Memory'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'MEMVEXA'),
        ],
      ),
    );
  }
}
