class ParsedRecallInput {
  final String raw;
  final String? item;
  final String? location;
  final String? container;
  final String? position;

  const ParsedRecallInput({
    required this.raw,
    this.item,
    this.location,
    this.container,
    this.position,
  });
}

class RecallParser {
  static String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  static bool _containsWord(String text, String word) {
    final escaped = RegExp.escape(word);
    return RegExp('(^|[^a-zäöüß])$escaped([^a-zäöüß]|\$)', caseSensitive: false).hasMatch(text);
  }

  static String? _findCanonical(String text, Map<String, List<String>> values) {
    for (final entry in values.entries) {
      for (final alias in entry.value) {
        if (_containsWord(text, alias)) return entry.key;
      }
    }
    return null;
  }

  static String? _extractItem(String original) {
    final patterns = <RegExp>[
      RegExp(r'^(?:mein|meine|meinen|meinem|meiner)\s+(.+?)\s+(?:liegt|liegen|steht|stehen|ist|sind|befindet|befinden)\b', caseSensitive: false),
      RegExp(r'^(.+?)\s+(?:liegt|liegen|steht|stehen)\s+(?:im|in|auf|unter|hinter|vor|bei)\b', caseSensitive: false),
      RegExp(r'(?:ich\s+habe|ich\s+lege|ich\s+stelle)\s+(?:den|die|das|meinen|meine|mein)?\s*(.+?)\s+(?:im|in|auf|unter|hinter|vor|bei)\b', caseSensitive: false),
    ];
    for (final pattern in patterns) {
      final match = pattern.firstMatch(original.trim());
      if (match != null) {
        final value = match.group(1)?.trim();
        if (value != null && value.isNotEmpty) return value;
      }
    }
    return null;
  }

  static String? _findPosition(String text) {
    final positions = <String, List<String>>{
      'oben rechts': ['oben rechts', 'obere rechte', 'oberen rechten', 'oberer rechter'],
      'oben links': ['oben links', 'obere linke', 'oberen linken', 'oberer linker'],
      'unten rechts': ['unten rechts', 'untere rechte', 'unteren rechten'],
      'unten links': ['unten links', 'untere linke', 'unteren linken'],
      'oben': ['oben', 'obere', 'oberen', 'oberer', 'oberes'],
      'unten': ['unten', 'untere', 'unteren', 'unterer', 'unteres'],
      'rechts': ['rechts', 'rechte', 'rechten', 'rechter'],
      'links': ['links', 'linke', 'linken', 'linker'],
      'hinten': ['hinten', 'hintere', 'hinteren'],
      'vorne': ['vorne', 'vordere', 'vorderen'],
      'mitte': ['mitte', 'mittlere', 'mittleren'],
    };
    return _findCanonical(text, positions);
  }

  static ParsedRecallInput parse(String input) {
    final original = input.trim();
    final text = _normalize(original);
    final rooms = <String, List<String>>{
      'wohnzimmer': ['wohnzimmer', 'stube'], 'küche': ['küche', 'kueche'], 'keller': ['keller'],
      'garage': ['garage'], 'schlafzimmer': ['schlafzimmer'], 'bad': ['bad', 'badezimmer'],
      'flur': ['flur', 'diele', 'eingangsbereich'], 'dachboden': ['dachboden', 'speicher'],
      'büro': ['büro', 'buero', 'arbeitszimmer'], 'abstellraum': ['abstellraum', 'kammer'],
      'garten': ['garten'], 'auto': ['auto', 'wagen', 'fahrzeug'],
    };
    final containers = <String, List<String>>{
      'schublade': ['schublade', 'schubladen'], 'schrank': ['schrank', 'schränke', 'schraenke'],
      'kiste': ['kiste', 'kisten'], 'regal': ['regal', 'regale'], 'tasche': ['tasche', 'taschen'],
      'geldbeutel': ['geldbeutel', 'portemonnaie', 'börse'], 'werkzeugkasten': ['werkzeugkasten', 'werkzeugkiste'],
      'box': ['box', 'boxen'], 'fach': ['fach', 'fächer', 'faecher'], 'korb': ['korb', 'körbe', 'koerbe'], 'ordner': ['ordner'],
    };
    return ParsedRecallInput(
      raw: original,
      item: _extractItem(original),
      location: _findCanonical(text, rooms),
      container: _findCanonical(text, containers),
      position: _findPosition(text),
    );
  }
}
