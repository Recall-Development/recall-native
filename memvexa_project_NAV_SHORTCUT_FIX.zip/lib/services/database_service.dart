import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/memory.dart';

class DatabaseService {
  DatabaseService._();
  static final instance=DatabaseService._();
  Database? _db;
  Future<Database> get database async {
    if(_db!=null)return _db!;
    final p=join(await getDatabasesPath(),'memvexa.db');
    _db=await openDatabase(p,version:1,onCreate:(db,v) async{
      await db.execute('CREATE TABLE memories(id TEXT PRIMARY KEY,title TEXT NOT NULL,content TEXT NOT NULL,category TEXT NOT NULL,notes TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE items(id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT,description TEXT,room TEXT,container TEXT,position TEXT,notes TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE locations(id TEXT PRIMARY KEY,name TEXT NOT NULL,parent_id TEXT,notes TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)');
      await db.execute('CREATE TABLE watch_items(id TEXT PRIMARY KEY,title TEXT NOT NULL,type TEXT NOT NULL,due_date TEXT,status TEXT NOT NULL,source_type TEXT,source_id TEXT,notes TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)');
    });
    return _db!;
  }
  Future<List<Memory>> listMemories({String? query}) async {
    final db=await database;
    final q=query?.trim()??'';
    final rows=await db.query('memories',
      where:q.isEmpty?null:'title LIKE ? OR content LIKE ? OR notes LIKE ?',
      whereArgs:q.isEmpty?null:['%$q%','%$q%','%$q%'],
      orderBy:'updated_at DESC');
    return rows.map(Memory.fromMap).toList();
  }

  Future<Memory?> latestMemory() async {
    final db=await database;
    final rows=await db.query('memories', orderBy:'updated_at DESC', limit:1);
    if(rows.isEmpty)return null;
    return Memory.fromMap(rows.first);
  }

  Future<void> saveMemory(Memory m) async {
    final db=await database;
    await db.insert('memories',m.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  }
  Future<void> deleteMemory(String id) async {
    final db=await database;
    await db.delete('memories',where:'id=?',whereArgs:[id]);
  }
  Future<int> count(String table) async {
    final db=await database;
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table'))??0;
  }
  Future<void> saveParsedEntities({String? item, String? location, String? container, String? position, required String raw}) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    if (item != null && item.trim().isNotEmpty) {
      final id = 'item:${item.trim().toLowerCase()}:${DateTime.now().microsecondsSinceEpoch}';
      await db.insert('items', {
        'id': id,
        'name': item.trim(),
        'category': 'Gegenstand',
        'description': raw,
        'room': location,
        'container': container,
        'position': position,
        'notes': null,
        'created_at': now,
        'updated_at': now,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    }
    if (location != null && location.trim().isNotEmpty) {
      final existing = await db.query('locations', where: 'LOWER(name)=?', whereArgs: [location.trim().toLowerCase()], limit: 1);
      if (existing.isEmpty) {
        await db.insert('locations', {
          'id': 'location:${location.trim().toLowerCase()}',
          'name': location.trim(),
          'parent_id': null,
          'notes': null,
          'created_at': now,
          'updated_at': now,
        }, conflictAlgorithm: ConflictAlgorithm.ignore);
      }
    }
  }

  Future<List<Map<String, Object?>>> listLocations() async {
    final db = await database;
    return db.query('locations', orderBy: 'name COLLATE NOCASE ASC');
  }

  Future<List<Map<String, Object?>>> listWatchItems() async {
    final db = await database;
    return db.query('watch_items', orderBy: 'updated_at DESC');
  }

  Future<void> saveWatchItem({required String id, required String title}) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    await db.insert('watch_items', {
      'id': id,
      'title': title,
      'type': 'watch',
      'due_date': null,
      'status': 'aktiv',
      'source_type': null,
      'source_id': null,
      'notes': null,
      'created_at': now,
      'updated_at': now,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteWatchItem(String id) async {
    final db = await database;
    await db.delete('watch_items', where: 'id=?', whereArgs: [id]);
  }

}
