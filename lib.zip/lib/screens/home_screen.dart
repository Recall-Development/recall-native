import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/memory.dart';
import '../services/database_service.dart';
import '../services/recall_parser.dart';
import 'memory_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>{
  final c=TextEditingController();
  int memories=0,items=0,locations=0;
  @override void initState(){super.initState();refresh();}
  Future<void> refresh() async{
    final v=await Future.wait([DatabaseService.instance.count('memories'),DatabaseService.instance.count('items'),DatabaseService.instance.count('locations')]);
    if(mounted)setState((){memories=v[0];items=v[1];locations=v[2];});
  }
  Future<void> analyze() async{
    final raw=c.text.trim(); if(raw.isEmpty)return;
    final p=RecallParser.parse(raw);
    final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(
      title:const Text('RECALL hat Folgendes erkannt'),
      content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Gegenstand: ${p.item??"nicht eindeutig"}'),
        Text('Ort: ${p.location??"nicht erkannt"}'),
        Text('Behälter: ${p.container??"nicht erkannt"}'),
        Text('Position: ${p.position??"nicht erkannt"}'),
        const SizedBox(height:12),
        const Text('Die Verarbeitung erfolgte vollständig lokal auf diesem Gerät.')
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Abbrechen')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('Speichern'))]
    ));
    if(ok!=true)return;
    final now=DateTime.now();
    await DatabaseService.instance.saveMemory(Memory(
      id:const Uuid().v4(),title:(p.item?.isNotEmpty??false)?p.item!:'Memory',content:raw,category:'Gegenstand',
      notes:[p.location,p.container,p.position].whereType<String>().join(' · '),createdAt:now,updatedAt:now));
    c.clear(); await refresh();
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Gespeichert – komplett lokal.')));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('RECALL'),actions:[IconButton(icon:const Icon(Icons.memory_outlined),onPressed:()async{await Navigator.push(context,MaterialPageRoute(builder:(_)=>const MemoryScreen()));refresh();})]),
    body:SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
      Text('Dein zweites Gedächtnis.',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.w700)),
      const SizedBox(height:8),
      const Text('Ohne Cloud-KI. Ohne laufende API-Kosten. Deine Daten bleiben auf deinem Gerät.'),
      const SizedBox(height:24),
      TextField(controller:c,minLines:2,maxLines:5,decoration:const InputDecoration(border:OutlineInputBorder(),hintText:'Was soll ich mir merken?',prefixIcon:Icon(Icons.auto_awesome))),
      const SizedBox(height:12),
      FilledButton.icon(onPressed:analyze,icon:const Icon(Icons.psychology_alt_outlined),label:const Text('RECALL analysieren')),
      const SizedBox(height:24),
      Row(children:[
        Expanded(child:_Stat('Gespeichert',memories)),const SizedBox(width:8),
        Expanded(child:_Stat('Gegenstände',items)),const SizedBox(width:8),
        Expanded(child:_Stat('Orte',locations))
      ]),
      const SizedBox(height:24),
      OutlinedButton.icon(onPressed:()async{await Navigator.push(context,MaterialPageRoute(builder:(_)=>const MemoryScreen()));refresh();},icon:const Icon(Icons.search),label:const Text('Memory durchsuchen'))
    ]))
  );
}
class _Stat extends StatelessWidget{
  final String label; final int value; const _Stat(this.label,this.value);
  @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.symmetric(vertical:18,horizontal:8),child:Column(children:[Text('$value',style:Theme.of(c).textTheme.headlineSmall),const SizedBox(height:4),FittedBox(child:Text(label))])));
}
